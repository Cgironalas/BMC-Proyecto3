Tecnológico de Costa Rica IC8022 - Introducción A La Biología Molecular Computacional

Profesor: Dr. Francisco Torres

Estudiantes: Carlos Girón Alas, Amanda Solano Astorga

Programa que alinea hileras generadas aleatoriamente con la técnica de alineamiento global en su versión normal (complejidad espacial cuadrática), y en su versión optimizada para espacio (complejidad espacial lineal).

Los archivos adjuntos son 
-ECvsEL.c
-ECvsEL.h
-GUI.glade
-makefile

También va el reporte escrito sobre las versiones de la técnica de alineamiento global.